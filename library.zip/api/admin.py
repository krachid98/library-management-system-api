from django.contrib import admin
from api.models import Libro, Preferiti

# Register your models here.
admin.site.register(Libro)
admin.site.register(Preferiti)
